export default {
    school:'hfuu' ,
    change: function(){
    console. log( "我们可以改变你!!");
    }
}