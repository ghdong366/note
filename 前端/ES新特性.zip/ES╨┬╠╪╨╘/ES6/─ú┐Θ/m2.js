let phone = 'xiaomi';
let man = {
    name:'tom',
    study(){
        console.log('study hard...');
    }
};
export{phone,man};