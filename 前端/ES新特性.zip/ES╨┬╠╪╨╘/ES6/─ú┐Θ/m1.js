export let name = 'tom';

export function show(){
    console.log('show something');
}