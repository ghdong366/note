module.exports = {
	lintOnSave:false, //关闭语法检查
}