<template>
  <div>
    <button @click="fun1">第一种封装，3个参数</button>
    <br>
    <button @click="fun2">第二种封装，1个参数</button>
  </div>
</template>

<script>
import {request1, request2} from "../network/request/request"

export default {
  name: "Demo",
  data() {
    return {}
  },
  methods: {
    fun1() {
      request1("http://localhost:9999/user/getAll",
          res => {
            console.log(res)
          }),
          err => {
            console.log(err)
          }
    },
    fun2() {
      request2({url: '/user/getAll',
       success:res=>{
        console.log(res)
      },
       fail:err=>{
        console.log(err)
      }})
    }
  }
}
</script>

<style scoped>
  button{
    height: 40px;
    margin-top: 5px;
  }
</style>