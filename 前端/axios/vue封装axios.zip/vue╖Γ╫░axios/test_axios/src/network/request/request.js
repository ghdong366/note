import axios from "axios";

// 第一种封装
function request1(config,success,fail){
    axios(config).then(res=>{
        success(res)
    }).catch(err=>{
        fail(err)
    })
}
//第二种封装
function request2(config){
    axios.defaults.baseURL='http://localhost:9999'
    axios(config.url).then(res=>{
        config.success(res)
    }).catch(err=>{
        config.fail(err)
    })
}
export {request1,request2}