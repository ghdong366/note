// vue.config.js
module.exports = {
    lintOnSave:false
}